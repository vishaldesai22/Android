package com.example.togglebutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.Toast;
import android.widget.ToggleButton;



import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ToggleButton t1 =(ToggleButton)findViewById(R.id.first1);
        ToggleButton t2=(ToggleButton)findViewById(R.id.second1);
        Button btn = (Button) findViewById(R.id.btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "toggle1 "+t1.getText().toString()+ "\n" + "toggle2" + t2.getText().toString()+"\n", Toast.LENGTH_SHORT).show();

            }
        });


    }
}