package com.example.traile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioButton r1 = findViewById(R.id.java1);
        RadioButton r2 = findViewById(R.id.python1);
        RadioButton r3 = findViewById(R.id.web);
        Button b1 = (Button)findViewById(R.id.btn1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r1.isChecked())
                {
                    Toast.makeText(MainActivity.this, "java is selected", Toast.LENGTH_SHORT).show();
                }
                if(r2.isChecked())
                {
                    Toast.makeText(MainActivity.this, "python is selected", Toast.LENGTH_SHORT).show();
                }
                if(r3.isChecked())
                {
                    Toast.makeText(MainActivity.this, "web developement is selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}