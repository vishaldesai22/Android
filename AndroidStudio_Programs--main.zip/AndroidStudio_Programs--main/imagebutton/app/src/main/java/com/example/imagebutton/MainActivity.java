package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;


import com.example.myapplication.R.id;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    EditText edit11,edit12,edit13;
    ImageButton btn11;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn11= (ImageButton) findViewById(R.id.btn1);
        edit11 = (EditText) findViewById(R.id.edit1);
        edit12 = (EditText)findViewById(R.id.edit2);
        edit13 = (EditText) findViewById(R.id.edit3);
        tv = (TextView)findViewById(R.id.textview1);
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edit11.getText().toString().isEmpty() || edit12.getText().toString().isEmpty() || edit13.getText().toString().isEmpty()) {
                    tv.setText("please fill al fields");
                } else {
                    tv.setText("name:" + edit11.getText().toString() + "\n" + "roll no is" + edit12.getText().toString() + "\n" + "mark =" + edit13.getText().toString() + "\n");
                }
            }
        });
    }
}